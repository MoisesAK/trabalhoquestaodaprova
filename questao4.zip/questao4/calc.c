int calc(int opcao,int n1, int n2)
{
	int resultado = 1;
	if (opcao == 1) {
		if (n1 == 0) {
			return resultado = 1;
		} else {
			for (int i = n1; i > 0 ; i--) {
				resultado = resultado * i;
			}
			return resultado;		
		}
	} 
	if (opcao == 2) {
		if (n2 == 0) {
			return resultado = 1;	
					
		} else if (n1 == 0) {
			return resultado = 0;
		} else {
			for (int q = n2 ; q > 0 ; q--) {
				resultado = resultado * n1;
			}
		}
		return resultado;
	}
}

	



