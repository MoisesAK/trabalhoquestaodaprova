#include<stdio.h>
#include"calc.h"

int main()
{
	int opcao = 0;
	int n1 = 0;
	int n2 = 0; 
		
	printf("Voce quer calcular o faltorial digite 1/nVoce quer calcular o numero elevado a expoente digite 2");
	scanf("%d", &opcao);
	if(opcao == 1) {
		printf("Digite o numero para fatorial");
		scanf("%d",&n1);
		calc(opcao,n1,n2);
	}
	if(opcao == 2) {
		printf("Digite os numeros para calcular o numero elevado");
		scanf("%d%d",&n1, &n2);
	}
	
	printf("%d", calc(opcao,n1,n2));
}


